from django.shortcuts import render
# from django.http import HttpResponse
from .models import inputfield


# Create your views here.
def index(request):
       return render (request,"frontend/index.html")

def form_submission(request):
       # print("Response Submitted")
       name = request.POST["name"]
       location = request.POST["location"]
       
       input= inputfield(name=name,location=location)
       input.save()
       return render(request,"frontend/index.html")
