from django.db import models

# Create your models here.

class inputfield(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=50)
    
    def __str__(self):
        return self.name

class address(models.Model):
    address = models.TextField()

    def __str__(self):
        return self.address