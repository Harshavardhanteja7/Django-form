from django.contrib import admin
from .models import inputfield,address
# Register your models here.
admin.site.register(inputfield)
admin.site.register(address)

